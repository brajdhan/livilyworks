
<?php $__env->startPush('title'); ?>
<title>Courses</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
<h1 class="text-center">Courses Page</h1>

<div class="row pb-5">
    <div class="col-sm-5">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <div class="card text-left">
                <div class="card-header">
                    <h4 class="card-title">Title</h4>
                </div>
                <div class="card-body">

                    <div class="form-group">
                        <label for="file">Profile</label>
                        <input type="file" class="form-control-file form-control-sm" name="profile" id="profile">
                        <small id="fileHelpId" class="form-text text-danger"><?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" class="form-control">
                        <small id="helpId" class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email">
                            <small id="emailHelpId" class="form-text text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                        </div>
                        <div class="form-group col-sm-6">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" name="phone" id="phone">
                            <small id="helpId" class="form-text text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small>
                        </div>
                    </div>
                    <div class="row pl-3">
                        <label for="gender">Gender</label>
                        <div class="form-check pl-5">
                            <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="sex" id="sex" value="Male" checked>
                                Male
                            </label>
                        </div>
                        <div class="form-check  pl-5">
                            <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="sex" id="sex" value="Female">
                                Female
                            </label>
                        </div>
                    </div>

                    <div class="row pl-3">
                        <label for="subject">Courses</label>
                        <div class="form-check pl-5">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" name="php" id="php" value="PHP" checked>
                                PHP
                            </label>
                        </div>
                        <div class="form-check pl-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" name="html" id="html" value="HTML" checked>
                                HTML
                            </label>
                        </div>
                        <div class="form-check pl-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" name="bootstrap" id="bootstrap" value="BOOTSTRAP" checked>
                                BOOTSTRAP
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" id="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>
            </div>
        </form>
    </div>
    <div class="col-sm-7">
        <div class="table-responsive">
            <table class="table table-dark bg-dark">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Profile</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Sex</th>
                        <th>Subject</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td scope="row">#</td>
                        <td><img src="" alt="profile"></td>
                        <td>Rajdhan</td>
                        <td>brajdhan@gmail.com</td>
                        <td>8888743320</td>
                        <td>Male</td>
                        <td>Game,Satta Matka</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        //insert Data
        $("#submit").on("click", function(event) {
            event.preventDefault();

            $.ajax({
                url: "<?php echo e(route('ajax.store')); ?>",
                type: "POST",
                data: FormData,
                success: function(data) {
                    if (data == 1) {
                        //alert(data);
                        $("#formData").trigger("reset");
                        $("#success").html("Data Added Successfully").slideDown();
                        $("#error").slideUp();
                        loadData();
                        setTimeout(function() {
                            $('#success').fadeOut('fast');
                        }, 2000)
                    } else {
                        //alert(data);
                        $("#error").html("Can't Save Record").slideDown();
                        $("#success").slideUp();
                        setTimeout(function() {
                            $('#error').fadeOut('fast');
                        }, 2000)
                    }
                }
            });

        })

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/ajax.blade.php ENDPATH**/ ?>