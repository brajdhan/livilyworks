<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Curd wuth file</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-12">
            <div id="success_message"></div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-center">Ajax Curd | Image
                            <a href="#" data-bs-toggle="modal" data-bs-target="#AddEmployerModal" class="btn btn-primary float-end btn-sm">Add Employer</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table></table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="AddEmployerModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="AddEmployerModalLabel">Add Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form id="AddEmployerFORM" method="post" enctype="multipart/form-data">

                    <div class="modal-body">

                        <ul id="save_errList"></ul>
                        <div class="form-group mb-3">
                            <label for="name">Employer Name</label>
                            <input type="text" name="name" id="name" class="name form-control">
                            <small class="text-danger"></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="name">Employer Email</label>
                            <input type="text" name="email" id="email" class="email form-control">
                            <small class="text-danger"></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="name">Employer Phone</label>
                            <input type="text" name="phone" id="phone" class="phone form-control">
                            <small class="text-danger"></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="name">Student Image</label>
                            <input type="file" name="image" id="image" class="image form-control">
                            <small class="text-danger"></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary add_employer">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {

             //csrf token
             $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

            $(document).on('click', '.add_employer', function(e) {
                e.preventDefault();
                //console.log('add_employer');
                var fromData = new FormData($('#AddEmployerFORM')[0]);
                //console.log(fromData);

                //ajax insert
                $.ajax({
                    type: "POST",
                    url: "/employers",
                    data: fromData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        //console.log(response);
                        if (response.status == 400) {
                            $('#save_errList').html('');
                            $('#save_errList').addClass('alert alert-warning');
                            $.each(response.errors, function(key, err_values) {
                                $('#save_errList').append('<li>' + err_values + '</li>');
                            });
                        } else if (response.status == 200){
                            //this.reset();
                            $('#success_message').addClass('alert alert-success');
                            $('#success_message').text(response.message);
                             //clear input fields
                            $('#AddEmployerModal').find('input').val('');
                            $('#AddEmployerModal').modal('hide');
                           
                            alert(response.message);
                            //fetchStudent();
                            
                        }
                    }
                });

            });
        });
    </script>
</body>

</html><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/employer/index.blade.php ENDPATH**/ ?>