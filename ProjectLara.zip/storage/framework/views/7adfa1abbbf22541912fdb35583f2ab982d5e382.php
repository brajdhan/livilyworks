<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Curd</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>



<div class="modal fade" id="AddStudentModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AddStudentModalLabel">Add Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
        <ul id="save_errList"></ul>
      <div class="form-group mb-3">
          <label for="name">Student Name</label>
          <input type="text" name="name" id="name" class="name form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Email</label>
          <input type="text" name="email" id="email" class="email form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Phone</label>
          <input type="text" name="phone" id="phone" class="phone form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Course</label>
          <input type="text" name="course" id="course" class="course form-control">
          <small class="text-danger"></small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary add_student">Save</button>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="editStudentModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editStudentModalLabel">Edit Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
        <ul id="update_errList"></ul>
        <input type="hidden" id="edit_studId">
      <div class="form-group mb-3">
          <label for="name">Student Name</label>
          <input type="text" name="name" id="edit_name" class="name form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Email</label>
          <input type="text" name="email" id="edit_email" class="email form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Phone</label>
          <input type="text" name="phone" id="edit_phone" class="phone form-control">
          <small class="text-danger"></small>
        </div>
        <div class="form-group mb-3">
          <label for="name">Student Course</label>
          <input type="text" name="course" id="edit_course" class="course form-control">
          <small class="text-danger"></small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary update_student">Update</button>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="deleteStudentModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteStudentModalLabel">Delete Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          
        <ul id="update_errList"></ul>
        <input type="hidden" id="delete_studId">
        <h4>Are You Sure ? want to delete this id ? </h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary delete_student_btn">Yes Delete</button>
      </div>
    </div>
  </div>
</div>


<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
        <div id="success_message"></div>
            <div class="card">
                <div class="card-header">
                    <h4>
                        Student Data
                    <a href="#" data-bs-toggle="modal" data-bs-target="#AddStudentModal" class="btn btn-primary float-end btn-sm">Add Student</a>
                
                    </h4>
                    
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NAME</th>
                                <th>EMAIL</th>
                                <th>PHONE</th>
                                <th>COURSE</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">

                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function(){
        //load data
        
        function fetchStudent(){
            $.ajax({
            type:'GET', 
            url:'fetchStudent',
            dataType:'json',
            success:function(response){
                //console.log(response.students);
                $('tbody').html('');
                $.each(response.students, function (key, value){
                    $('tbody').append(`<tr>
                    <td>`+ value.id +`</td>\
                    <td>`+ value.name +`</td>\
                    <td>`+ value.email +`</td>\
                    <td>`+ value.phone +`</td>\
                    <td>`+ value.course +`</td>\
                    <td>\
                        <button type="button" data-bs-toggle="modal" data-bs-target="#editStudentModal" value="`+ value.id +`" class="edit_sudent btn btn-primary btn-sm">Edit</button>\
                        <button type="button" data-bs-toggle="modal" data-bs-target="#deleteStudentModal" value="`+ value.id +`" class="delete_sudent btn btn-danger btn-sm">Delete</button>\
                    </td>\
                    </tr>`);
                    });
                }
            });
        }
        fetchStudent();
        //end load data
        //insert data
        $(document).on('click','.add_student', function(e){
            e.preventDefault();
            //console.log('hi');
            var data = {
                'name':$('.name').val(),
                'email':$('.email').val(),
                'phone':$('.phone').val(),
                'course':$('.course').val()
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'POST',
                url:'/students',
                data:data,
                dataType:'json',
                success:function(response){
                    //console.log(response);
                    if(response.status == 400){
                        $('#save_errList').html('');
                        $('#save_errList').addClass('alert alert-danger');
                        $.each(response.errors, function(key, err_values){
                           $('#save_errList').append('<li>'+err_values+'</li>') ;
                        });
                    }else{
                        $('#success_message').addClass('alert alert-success');
                        $('#success_message').text(response.message);
                        $('#AddStudentModal').modal('hide');
                        $('#AddStudentModal').find('input').val('');
                        fetchStudent();
                    }
                }
            })
        });
        //end insert data

        //edit data
        $(document).on('click', '.edit_sudent', function(e){
            e.preventDefault();
            var studId = $(this).val();
            //console.log(studId);
            $('#editStudentModal').modal('show');
            $.ajax({
                type:'GET',
                url:'/edit-student/'+studId,
                success:function(response){
                    //console.log(response);
                    if(response.status == 404){
                        $('#success_message').html('');
                        $('#success_message').addClass('alert alert-danger');
                        $('#success_message').text(response.message)
                    }else{
                        $('#edit_studId').val(studId);
                        $('#edit_name').val(response.student.name);
                        $('#edit_email').val(response.student.email);
                        $('#edit_phone').val(response.student.phone);
                        $('#edit_course').val(response.student.course);
                    }
                }
            });
        });
        //end edit data

        //update data
        $(document).on('click','.update_student', function(e){
            e.preventDefault();
            $(this).text('Updating');
            var studId = $('#edit_studId').val();
            var data = {
                'name':$('#edit_name').val(),
                'email':$('#edit_email').val(),
                'phone':$('#edit_phone').val(),
                'course':$('#edit_course').val()
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "PUT",
                url:'/update-student/'+studId,
                data: data,
                dataType: "json",
                success: function (response) {
                    //console.log(response);

                    if(response.status == 400){
                        //errors
                        $('#update_errList').html('');
                        $('#update_errList').addClass('alert alert-danger');
                        $.each(response.errors, function(key, err_values){
                           $('#update_errList').append('<li>'+err_values+'</li>') ;
                        });
                        $('update_student').text('Update');
                    }else if(response.status == 404){
                        $('#update_errList').html('');
                        $('#success_message').addClass('alert alert-danger');
                        $('#success_message').text(response.message);

                        $('.update_student').text('Update');

                    }else{
                        $('#update_errList').html('');
                        $('#success_message').html('');
                        $('#success_message').addClass('alert alert-success');
                        $('#success_message').text(response.message);
                    
                        $('#editStudentModal').modal('hide');
                        $('.update_student').text('Update');
                        fetchStudent();
                    }
                }
            });
        });
        //end update data

        //display delete conformation
        $(document).on('click','.delete_sudent', function(e){
            e.preventDefault();
            //$(this).text('Deleting');
            var studId = $(this).val();
            //console.log(studId);
            
            var studId = $('#delete_studId').val(studId);
            $('#deleteStudentModal').modal('show');

        });
        //end display delete conformation

        //delete data
        $(document).on('click','.delete_student_btn', function (e) {
            e.preventDefault();
            var studId = $('#delete_studId').val();
            
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "DELETE",
                url: "/delete-student/"+studId,
                success: function (response) {
                 console.log(response);
                    if(response.status == 200){
                        $('#success_message').html('');
                        $('#success_message').addClass('alert alert-success');
                        $('#success_message').text(response.message);
                    
                        $('#deleteStudentModal').modal('hide');
                        fetchStudent();   
                    }else{
                        $('#success_message').html('');
                        $('#success_message').addClass('alert alert-danger');
                        $('#success_message').text(response.message);
                    }
                }
            });
        });
        //end delete data

    });
</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/student/index.blade.php ENDPATH**/ ?>