<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="/upload" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <input type="file" name="photo">
            <input type="submit" value="Submit">
    </form>
    <ul>
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($p->name); ?></li>
        <li><img src="<?php echo e(asset('storage/images/')); ?>/<?php echo e($p->name); ?>" alt="" width="100px"></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</body>
</html><?php /**PATH D:\xampp\htdocs\Laravel\ProjectLara\resources\views/upload.blade.php ENDPATH**/ ?>