<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DemoController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\RazorpayController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\SingleActionController;
use App\Http\Controllers\WebsiteController;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\EmployerController;
use App\Http\Controllers\ThecherController;
use Illuminate\Support\Facades\Route;
use App\Models\Customer;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/example/{name?}',function($name=null){
    $demo ="<h1>Welcode Brajdhan</h1>";
    $data =compact('name','demo');
    return view('/example/directive')->with($data);
});

// without controller

// Route::get('/', function(){
//     //return view('home');
// });

// Route::get('/about', function(){
//     return view('about');
// });

//with basic controller 
Route::get('/',[DemoController::class,'index']);
Route::get('/about',[DemoController::class,'about']);
// single ction controoler
Route::get('/courses',SingleActionController::class);
//resource controller
Route::resource('photo',PhotoController::class);

//registration controller
Route::get('/register', [RegistrationController::class,'index']);
Route::post('/register', [RegistrationController::class,'register']);
//componenet file input Data
Route::get('/componentform', [RegistrationController::class,'componentform']);
Route::post('/componentform', [RegistrationController::class,'componentformregister']);

// Route::get('/customer', function(){
//     $customers = Customer::all();
//     //print_r($customers->toArray());
//     return view('customer');
// });

Route::get('/customer/create',[CustomerController::class,'create'])->name('customer.create');
Route::get('/customer/delete/{id}',[CustomerController::class,'delete'])->name('customer.delete');
Route::get('/customer/edit/{id}',[CustomerController::class,'edit'])->name('customer.edit');
Route::post('/customer/update/{id}',[CustomerController::class,'update'])->name('customer.update');
Route::post('/customer',[CustomerController::class,'store']);
Route::get('/customer',[CustomerController::class,'view']);

Route::get('/upload', [PhotoController::class, 'create']);
Route::post('/upload', [PhotoController::class, 'store']);

Route::get('get-all-session', function(){
    $session = session()->all();
    brajdhan($session);
});

Route::get('set-session', function(Request $request)
{
    $request->session()->put('name',"brajdhan");
    $request->session()->put('id',"123");
    $request->session()->flash('status', 'success');
    return redirect('get-all-session');
});

Route::get('distroy-session', function(){
    session()->forget(['name','id']);
    //session()->forget('id');
    return redirect('get-all-session');
});

Route::get('mail',[WebsiteController::class,'index']);


Route::get('payment', [RazorpayController::class, 'index']);
Route::get('paysuccess', [RazorpayController::class, 'razorPaySuccess']);
Route::get('razor-thank-you', [RazorpayController::class, 'RazorThankYou']);

/******************* */
Route::get('ajax',[AjaxController::class, 'index'])->name('ajax.home');
Route::post('ajax',[AjaxController::class, 'store'])->name('ajax.store');

/**************Ajax  Curd ************* */
Route::get('/students',[StudentController::class, 'index'])->name('student');
Route::get('/fetchStudent',[StudentController::class, 'fetchStudent']);
Route::get('/edit-student/{id}',[StudentController::class,'edit']);

Route::post('/students',[StudentController::class, 'store']);
Route::put('/update-student/{id}',[StudentController::class,'update']);
Route::delete('/delete-student/{id}',[StudentController::class,'destroy']);

/**************************************************** */
Route::get('/employers',[EmployerController::class, 'index'])->name('employers');
Route::post('/employers',[EmployerController::class, 'store']);

/************************ */
Route::get('/teacher', [ThecherController::class, 'index']);
Route::post('/teacher/store', [ThecherController::class, 'store'])->name('store');
Route::get('/teacher/fetchall', [ThecherController::class, 'fetchAll'])->name('fetchAll');
Route::delete('/teacher/delete', [ThecherController::class, 'delete'])->name('delete');
Route::get('/teacher/edit', [ThecherController::class, 'edit'])->name('edit');
Route::post('/teacher/update', [ThecherController::class, 'update'])->name('update');


// Ctegory Routes

Route::get('/category', [CategoryController::class, 'index'])->name('category');
Route::post('/category/store', [CategoryController::class, 'store'])->name('store.category');

// articles Routes
Route::get('/articles', [ArticleController::class, 'index'])->name('articles');
Route::post('/articles/store', [ArticleController::class, 'store'])->name('store.articles');

Route::get('/articlesCatData/{id}', [CategoryController::class, 'category'])->name('articlesCatData');