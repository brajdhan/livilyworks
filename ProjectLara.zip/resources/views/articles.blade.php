<!doctype html>
<html lang="en">
  <head>
    <title>Category</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <form action="{{route('store.articles')}}" method="post">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Article Add</h4>
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                              <label for="">Article Title</label>
                              <input type="text" name="article_title" value="{{ old('article_title')}}" class="form-control form-control-sm" aria-describedby="helpId">
                              <small id="helpId" class="text-danger">
                                @error('category_title')
                                {{$message}}
                                @enderror
                              </small>
                            </div>

                            <div class="form-group">
                                <label for="">Article Slug</label>
                                <input type="text" name="slug"  value="{{ old('slug')}}" class="form-control form-control-sm" aria-describedby="helpId">
                                <small id="helpId" class="text-danger">
                                    @error('slug')
                                    {{$message}}
                                    @enderror
                                </small>
                            </div>
                            
                            <div class="form-group">
                              <label for="">Article Text</label>
                              <textarea class="form-control" name="article_text" rows="3">{{ old('article_text')}}</textarea>
                              <small id="helpId" class="text-danger">
                                @error('article_text')
                                {{$message}}
                                @enderror
                            </small>
                            </div>

                            <div class="form-group">
                              <label for="">Article Category</label>
                              <select class="form-control form-control-sm" name="category_id">
                                @foreach ($category as $item)
                                   <option value="{{ $item->_id }}">{{$item->category_title}}</option>
                                @endforeach
                              </select>
                            </div>

                        </div>
                        <div class="card-footer text-muted">
                            <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>