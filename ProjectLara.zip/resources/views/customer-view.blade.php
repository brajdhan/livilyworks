@extends('layouts.main')
@push('title')
<title>Customer Details</title>
@endpush
@section('main-section')
<div class="container">
    <div class="row m-auto pt-5">
        <div class="col-md-12 m-auto">
            <a href="{{route('customer.create')}}">
                <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
            </a>
            <!-- {{print_r($customers)}} -->
            <table class="table">
                <thead>
                    <tr>
                        <th>Sr No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>DOB</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach( $customers as $customer)
                    <tr>
                        <td scope="row">{{$customer->costomers_id }}</td>
                        <td>{{$customer->name}}</td>
                        <td>{{$customer->email}}</td>
                        <td>
                            @if($customer->gender =='M')
                                Male
                            @elseif($customer->gender =='F')
                                Female 
                            @else
                                Other
                            @endif
                        </td>
                        <td>{{$customer->state}}</td>
                        <td>{{$customer->country}}</td>
                         <td>
                             <!-- with helper autoload file -->
                             <!--{{ get_formated_date($customer->dob, 'd-M-Y')}} -->
                             {{$customer->dob}}

                        </td>
                        <td>
                            @if($customer->status=='1')
                                <span class="badge badge-success p-1">Active</span>
                            @else
                                 <span class="badge badge-danger p-1">Inactive</span>
                            @endif
                        </td>
                        <td>
                            <a href="{{url('/customer/edit/')}}/{{$customer->costomers_id}}" class="badge badge-primary">Edit</a>
                            <a href="{{route('customer.edit',['id'=>$customer->costomers_id])}}" class="badge badge-primary">Edit</a>
                            <a href="{{url('/customer/delete/')}}/{{$customer->costomers_id}}" class="badge badge-danger">Delete</a>
                            <a href="{{route('customer.delete',['id'=>$customer->costomers_id])}}" class="badge badge-danger">Route link Delete</a>
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection