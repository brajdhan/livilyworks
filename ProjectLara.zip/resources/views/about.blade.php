@extends('layouts.main')
@push('title')
<title>About</title>
@endpush
@section('main-section')
<h1 class="text-center">About PAge</h1>
@endsection