<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="/upload" method="post" enctype="multipart/form-data">
        @csrf
            <input type="file" name="photo">
            <input type="submit" value="Submit">
    </form>
    <ul>
    @foreach($photos as $p)
        <li>{{$p->name}}</li>
        <li><img src="{{ asset('storage/images/') }}/{{ $p->name }}" alt="" width="100px"></li>
    @endforeach

    </ul>
</body>
</html>