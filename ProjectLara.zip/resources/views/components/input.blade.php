<div class="form-group">
    <label for="">{{$label}}</label>
    <input type="{{$type}}" name="{{$name}}" class="form-control">
    <small id="helpId" class="text-danger">
    <!-- {{$demo}} -->
         @error($name)
        {{$message}}
        @enderror
    </small>
</div>