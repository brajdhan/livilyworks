<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    use HasFactory;
    protected $table = 'articles';
    protected $primaryKey = '_id';
    protected $fillable= ['_uid','article_title', 'slug', 'article_text'];


    public function parentCategory()
    {
        return $this->belongsTo(Article::class, 'category_id');

    }

    public function childCategories()
    {
        return $this->hasMany(Article::class, 'category_id');

    }

}
