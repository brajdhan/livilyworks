<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $table = 'costomers';
    protected $primaryKey = 'costomers_id';

    //mutator
    // if i have feild name with undorcore (_) like (user_name) that time use- setUserNameAttribute otherwise use setNameAttribute
    public function setNameAttribute($value){
        $this->attributes['name']=ucwords($value);
    }
    
    //Accessor
    public function getDobAttribute($value){
        return date('d-M-Y',strtotime($value));
    }
}
