<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ajax;
class AjaxController extends Controller
{
    function index()
    {
        return view('ajax');
    }

    
    function store(Request $request)
    {
        $request->validate(
            [
                'name' => 'required',
                'email' => 'required|email|unique:ajaxes',
                'phone' => 'required',
                'profile' => 'required',
               
            ] 
        );
        //dd($_POST);
        $ajax =new Ajax;
        $ajax->profile = $request->file('profile')->store('images');
        return redirect('ajax');
    }
    
}
