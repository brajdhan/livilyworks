<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class CategoryController extends Controller
{
    public function index()
    {
        $category = Category::all();

        return view('category', ['category'=>$category]);
    }


    public function store(Request $request)
    {
        $request->validate(
            [
                'category_title'=>'required',
                'slug' => 'required|unique:categories,slug|regex:/(^[a-zA-Z]+[a-zA-Z0-9\\-]*$)/u',
            ]
        );
       
        $category = new Category;
        $category->_uid = Str::random(30);
        $category->category_title = $request->category_title;
        $category->slug = $request->slug;
        $category->parent_category_id = $request->parent_category_id;
        $category->save();
        return redirect('category');
    }

    public function getCategoryTreeIDs($catID=Null) {
        $row = Category::where('_id', $catID)->first();
        $path = array();
        if (!$row['parent_category_id'] != Null) {
          $path[] = $row['parent_category_id'];
          $path = array_merge($this->getCategoryTreeIDs($row['parent_category_id']), $path);
        }
        return $path;
      }
      
      
      public function getCategoryTitle($id=Null){
        $c = Category::where('_id', $id)->first();
        return $c->name;
      }
}
