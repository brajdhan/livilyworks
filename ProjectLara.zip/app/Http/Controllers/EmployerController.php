<?php

namespace App\Http\Controllers;
use App\Models\Employer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EmployerController extends Controller
{
    public function index()
    {
        return view('employer.index');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name'=>'required|max:191',
            'email'=>'required|email|max:191|unique:employers',
            'phone'=>'required|max:191',
            'image'=>'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        if($validator->fails()){
            return response()->json([
                'status'=>400,
                'errors'=>$validator->errors()->getMessages()
            ]);
        }else{
            $employer = new Employer;
            $employer->name = $request->input('name');
            $employer->email = $request->input('email');
            $employer->phone = $request->input('phone');
            $employer->image = $request->input('image');

            if ($request->hasFile('image')) {
               $file = $request->file('image');
               $extension = $file->getClientOriginalExtension();
               $filename = time() .'.'.  $extension;
               $file->move('uploads/employer',$filename);
               $employer->image = $filename;
            }
            $employer->save();
            return response()->json([
                'status'=>200,
                'message'=>'Added Employer Successfully',
            ]);
        }
    }

    
}
