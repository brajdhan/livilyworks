<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ArticleController extends Controller
{
    protected $category;
    public function __construct(){    
    }

    
    public function index()
    {
        $category = DB::table('categories')->get();
        return view('articles', ['category'=>$category]);
    }

    
    public function category(Article $category, Article $childCategory = null, $childCategory2 = null)
    {
        $products = null;
        $ids = collect();
        $selectedCategories = [];

        if ($childCategory2) {
            $subCategory = $childCategory->childCategories()->where('slug', $childCategory2)->firstOrFail();
            $ids = collect($subCategory->id);
            $selectedCategories = [$category->id, $childCategory->id, $subCategory->id];
        } elseif ($childCategory) {
            $ids = $childCategory->childCategories->pluck('_id');
            $selectedCategories = [$category->id, $childCategory->id];
        } elseif ($category) {
            $category->load('childCategories.childCategories');
            $ids = collect();
            $selectedCategories[] = $category->id;

            foreach ($category->childCategories as $subCategory) {
                $ids = $ids->merge($subCategory->childCategories->pluck('_id'));
            }
        }
        
        $products = Article::whereHas('categories', function ($query) use ($ids) {
                $query->whereIn('id', $ids);
            })
            ->with('categories.parentCategory.parentCategory')
            ->paginate(9);
            dd($products);

        return view('index', compact('products', 'selectedCategories'));
    }
    

    public function store(Request $request)
    {
        $request->validate(
            [
                'article_title'=>'required',
                'slug' => 'required|unique:categories,slug|regex:/(^[a-zA-Z]+[a-zA-Z0-9\\-]*$)/u',
                'article_text'=>'required'
            ]
        );
       
        $Article = new Article;
        $Article->_uid = Str::random(30);
        $Article->article_title = $request->article_title;
        $Article->slug = $request->slug;
        $Article->article_text = $request->article_text;
        $Article->category_id = $request->category_id;
        $Article->save();
        return redirect('articles');
    }


    public function getCategoryTreeForParentId($parent_id = 0) {
        $categories = array();

        $this->db->from('categories');
        $this->db->where('parent_id', $parent_id);
        $result = $this->db->get()->result();
        foreach ($result as $mainCategory) {
          $category = array();
          $category['id'] = $mainCategory->id;
          $category['name'] = $mainCategory->name;
          $category['parent_id'] = $mainCategory->parent_id;
          $category['sub_categories'] = $this->getCategoryTreeForParentId($category['id']);
          $categories[$mainCategory->id] = $category;
        }
        return $categories;
      }
}
