<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class WebsiteController extends Controller
{
    public function index()
    {
        $data =[
            'name'=> 'Rajdhan',
            'data'=>'Hello Brajdhan'
        ];
        $user['to'] = 'brajdhan@gmail.com';
        Mail::send('mail',$data,function($messages) use ($user){
            $messages->to('brajdhan@gmail.com');
            $messages->subject('Hello');
        });
    }
}
