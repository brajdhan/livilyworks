<?php 
include('config.php');
$username= $_POST['username'];
$password = $_POST['password'];
$sql = "SELECT * FROM `student` WHERE username='{$username}' AND password ='{$password}'";
$qry = mysqli_query($con, $sql) or die('SQL query Dailed');
if(mysqli_num_rows($qry) > 0){
    echo 1;
}else{
    echo 0;
}

?>