<?php 
include('config.php');
$fname = $_POST['fname'];
$lname = $_POST['lname'] ;
$username= $_POST['username'];
$email = $_POST['email'];
$contact= $_POST['contact'];
$dob=$_POST['dob'];
$password = $_POST['password']; 
$cpassword = $_POST['cpassword'];
$address = $_POST['address'];
//$pro_pic = $_FILE['pro_pic']; 

//print_r($_FILE['pro_pic']);
//exit();

$sql = "INSERT INTO `student`( `fname`, `lname`, `username`, `email`, `address`, `contact`, `dob`, `password`, `cpassword`) VALUES ('{$fname}','{$lname}', '{$username}','{$email}','{$address}','{$contact}','{$dob}','{$password}','{$cpassword}')";
if(mysqli_query($con, $sql)){
    echo 1;
}else{
    echo 0;
}
?>