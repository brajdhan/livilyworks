<?php 
include('config.php');

$sql = "SELECT * FROM `student`";
$data = "";
$result = mysqli_query($con, $sql) or die('SQL Query Failed');

if(mysqli_num_rows($result)>0){
    while($row = mysqli_fetch_assoc($result)){
        echo $data = "<tr>
            <td>{$row['id']}</td>
            <td>{$row['fname']} {$row['lname']}</td>
            <td>{$row['username']}</td>
            <td>{$row['email']}</td>
            <td>{$row['address']}</td>
            <td>{$row['contact']}</td>
            <td>{$row['dob']}</td>
            <td>{$row['password']}</td>
            <td>
            <button class='btn btn-primary btn-sm edit-btn' data-eid='{$row['id']}'>Edit</button>
            <button class='btn btn-danger btn-sm m-2 delete-btn' data-did='{$row['id']}'>Delete</button>
            </td>
        </tr>";
    }
}else{
    echo "<td colspan='9' class='text-center'>No Record Found</td>";
}
