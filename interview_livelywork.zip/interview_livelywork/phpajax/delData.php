<?php
include('config.php');
$id = $_POST['id'];

$sql ="DELETE FROM `student` WHERE `id`= '{$id}'";
if(mysqli_query($con, $sql)){
    echo 1;
}else{
    echo 0;
}

?>