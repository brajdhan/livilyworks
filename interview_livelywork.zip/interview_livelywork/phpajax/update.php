<?php 
include('config.php');
$id = $_POST['id'];
$fname = $_POST['fname'];
$lname = $_POST['lname'] ;
$username= $_POST['username'];
$email = $_POST['email'];
$contact= $_POST['contact'];
$dob=$_POST['dob'];
$address = $_POST['address'];

$sql = "UPDATE `student` SET `fname`='{$fname}',`lname`='{$lname}',`username`='{$username}',`email`='{$email}',`address`='{$address}',`contact`='{$contact}',`dob`='{$dob}' WHERE `id`='{$id}'";
if(mysqli_query($con, $sql)){
echo 1;
}else{
    echo 0;
}
?>