<?php 
include('config.php');
$id=$_POST['id'];

$sql = "SELECT * FROM `student` WHERE `id` = {$id}";
$data = "";
$result = mysqli_query($con, $sql) or die("SQL Query Failed");
if(mysqli_num_rows($result)){
    while($row = mysqli_fetch_assoc($result)){
        echo $data ="
        <tr>
    <td>First Name</td>
    <td>
        <input type='hidden' class='form-control form-control-sm' id='e-id' value='{$row['id']}'>
        <input type='text' class='form-control form-control-sm' id='e-fname' value='{$row['fname']}'>
    </td>
</tr>
<tr>
    <td>Last Name</td>
    <td><input type='text' class='form-control-sm form-control' id='e-lname' value='{$row['lname']}'></td>
</tr>
<tr>
    <td>Username</td>
    <td><input type='text' class='form-control form-control-sm' id='e-username' value='{$row['username']}'></td>
</tr>
<tr>
    <td>Email</td>
    <td><input type='email' class='form-control-sm form-control' id='e-email' value='{$row['email']}'></td>
</tr>
<tr>
    <td>Address</td>
    <td><textarea  class='form-control form-control-sm' id='e-address' cols='30' rows='3'>{$row['address']}</textarea></td>
</tr>
<tr>
    <td>Contact</td>
    <td><input type='text' class='form-control form-control-sm' id='e-contact' value='{$row['contact']}'></td>
</tr>
<tr>
    <td>Dob</td>
    <td><input type='date' class='form-control form-control-sm' id='e-dob' value='{$row['dob']}'></td>
</tr>
<tr>
    <td colspan='2'><button class='btn btn-primary btn-sm' id='update-submit'> Update</button></td>
</tr>
";
    }

}


?>



